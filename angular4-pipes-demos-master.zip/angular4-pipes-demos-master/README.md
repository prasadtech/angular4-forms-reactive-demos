## Pipes Demo
    - All Pipes Are covered
    - Creating a custom pipe is covered