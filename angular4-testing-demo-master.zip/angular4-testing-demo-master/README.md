[![Build Status](https://travis-ci.org/ArunaChinnathambi/Angular4-Testing.svg?branch=master)](https://travis-ci.org/ArunaChinnathambi/Angular4-Testing)

[![Coverage Status](https://coveralls.io/repos/github/ArunaChinnathambi/Angular4-Testing/badge.svg?branch=master)](https://coveralls.io/github/ArunaChinnathambi/Angular4-Testing?branch=master)

[![codecov](https://codecov.io/gh/ArunaChinnathambi/Angular4-Testing/branch/master/graph/badge.svg)](https://codecov.io/gh/ArunaChinnathambi/Angular4-Testing)

[![Codacy Badge](https://api.codacy.com/project/badge/Grade/17ea8594379442d3a354b06a38909691)](https://www.codacy.com/app/ArunaChinnathambi/Angular4-Testing?utm_source=github.com&amp;utm_medium=referral&amp;utm_content=ArunaChinnathambi/Angular4-Testing&amp;utm_campaign=Badge_Grade)

# Angular4-Testing
