import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-module-b',
  templateUrl: './module-b.component.html',
  styles: []
})
export class ModuleBComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
