import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-module-c',
  templateUrl: './module-c.component.html',
  styles: []
})
export class ModuleCComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
