package com.heapdump.analysis;

public class ObjectForLeak {

	private void dispaly() {
		
		System.out.println("Inside the leak method");
	}
}
