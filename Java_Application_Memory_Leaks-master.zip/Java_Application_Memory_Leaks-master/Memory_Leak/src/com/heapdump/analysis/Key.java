package com.heapdump.analysis;
public class Key {
    public static String key;
    
    public Key(String key) {
        Key.key = key;
    }
}