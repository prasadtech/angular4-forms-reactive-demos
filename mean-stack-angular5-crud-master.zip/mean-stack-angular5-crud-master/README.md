# MEAN Stack (Angular 5) CRUD Web Application Example


To run locally:

* Clone this repo
* Run `npm install`
* Run `npm start`

By defualt it launches on 3000 port.

use the below URL to connect
# http://localhost:3000

# Notes 
    - Start Mongo Server on your local 
