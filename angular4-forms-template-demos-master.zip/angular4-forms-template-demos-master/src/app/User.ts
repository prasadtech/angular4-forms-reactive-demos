export class User  {

  constructor(
   public  username: string,
   public email: string,
   public secretQuestion: string,
   public  answer: string,
   public  gender: string) {}
  }
